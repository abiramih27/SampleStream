﻿using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Net;
using System.Net.Http.Headers;
using System.Web;
using Tweetinvi;
using TwitterAPIAnalyzis;

//string twitterAccessKeyValue = ConfigurationManager.AppSettings["TwitterAccessKey"].ToString();
//string twitterSecretKeyValue = ConfigurationManager.AppSettings["TwitterSecretKey"].ToString();
////string BearerToken = ConfigurationManager.AppSettings["BearerToken"].ToString();

//TwitterClient twitterClient = new TwitterClient(twitterAccessKeyValue, twitterSecretKeyValue);
//TwitterRequest request2 = new TwitterRequest();

string url = "https://api.twitter.com/2/tweets/sample/stream";
//string url = "https://api.twitter.com/2/tweets/sample10/stream?partition=2";
TwitterStream.TwitterApiGetCall(url);






