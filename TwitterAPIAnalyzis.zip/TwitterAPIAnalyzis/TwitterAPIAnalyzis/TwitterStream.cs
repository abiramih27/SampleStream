﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Net;
using System.Net.Http.Headers;
using System.Web;
using System.Reflection.Metadata;
using System.Security.Policy;
using Nancy;
using HttpStatusCode = System.Net.HttpStatusCode;
using Nancy.Json;

namespace TwitterAPIAnalyzis
{
    public class TwitterStream
    {
        public static JObject TwitterApiGetCall(string address)
        {
            string BearerToken = ConfigurationManager.AppSettings["BearerToken"].ToString();
            WebRequest request = WebRequest.Create(address);
            request.Headers.Add("Authorization", "Bearer " + BearerToken);
            request.Method = "GET";
           // request.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
            request.ContentType = "application/json";
            string responseJson = string.Empty;

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                responseJson = new StreamReader(responseStream).ReadToEnd();
            }

            JObject jobjectResponse = JObject.Parse(responseJson);
            return jobjectResponse;
        }



        public static async Task TwitterApiGetCall1(string address)
        {
            string BearerToken = ConfigurationManager.AppSettings["BearerToken"].ToString();

            var requestUserTimeline = new HttpRequestMessage(HttpMethod.Get, "https://api.twitter.com/2/tweets/sample/stream.json");
             string url = "https://api.twitter.com/2/tweets/sample/stream";

            //string url = "https://api.twitter.com/2/tweets/sample/stream?tweet.fields=created_at&expansions=author_id&user.fields=created_at\r\n\r\nCode copied to clipb";
           // string url = "https://api.twitter.com/2/tweets/sample/stream?user.fields";
            requestUserTimeline.Headers.Add("Authorization", "Bearer " + BearerToken);
           // requestUserTimeline.Headers.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", BearerToken);
            //httpClient.Timeout = TimeSpan.FromMinutes(30);

            Stream response= await httpClient.GetStreamAsync(url);
            string responseJson = string.Empty;
            responseJson = new StreamReader(response).ReadToEnd();
            //HttpResponseMessage responseUserTimeLine = await httpClient.SendAsync(requestUserTimeline);
            //var serializer = new JavaScriptSerializer();
            //dynamic json = serializer.Deserialize<object>(await responseUserTimeLine.Content.ReadAsStringAsync());
            //var enumerableTweets = (json as IEnumerable<dynamic>);


            //var values = new List<KeyValuePair<string, string>>();
            //values.Add(new KeyValuePair<string, string>("id", param.Id.Value));
            //values.Add(new KeyValuePair<string, string>("type", param.Type.Value));
            //var content = new FormUrlEncodedContent(values);
            //using (var client = new HttpClient())
            //{
            //    client.BaseAddress = new Uri(address);
            //    client.DefaultRequestHeaders.Clear();
            //    client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));

            //    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //    //string token = param.token.Value;
            //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", BearerToken);


            //    var response = await client.GetAsync("/2/tweets/sample/stream");
            //    if (response.IsSuccessStatusCode)
            //    {
            //        var result = response.Content.ReadAsStringAsync().Result;

            //        //return Request.CreateResponse(HttpStatusCode.OK, result);
            //    }

            //    //var response = client.PostAsync("/2/tweets/sample/stream", content).Result;
            //    string responseJson = string.Empty;
            //    //if (response.IsSuccessStatusCode)
            //    //{
            //    //    var result = response.Content.ReadAsStringAsync().Result;
            //    //    //return Request.CreateResponse(HttpStatusCode.OK, result);

            //    //    //Stream responseStream = response.GetResponseStream();
            //    //    //responseJson = new StreamReader(responseStream).ReadToEnd();
            //    //}
            //    JObject jobjectResponse = JObject.Parse(responseJson);
            //    //return jobjectResponse;
            //    // return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "fail");
            //}
        }


    }
}
