﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Net;
using System.Net.Http.Headers;
using System.Web;
using System.Reflection.Metadata;
using System.Security.Policy;

namespace TwitterAPIAnalyzis
{
    public class TwitterStream
    {
        public static JObject TwitterApiGetCall(string address)
        {
            string BearerToken = ConfigurationManager.AppSettings["BearerToken"].ToString();
            WebRequest request = WebRequest.Create(address);
            request.Headers.Add("Authorization", "Bearer " + BearerToken);
            request.Method = "GET";
           // request.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
            request.ContentType = "application/json";
            string responseJson = string.Empty;

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                responseJson = new StreamReader(responseStream).ReadToEnd();
            }

            JObject jobjectResponse = JObject.Parse(responseJson);
            return jobjectResponse;
        }

        
    }
}
